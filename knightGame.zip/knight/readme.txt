This game requires Python 3.

To run the game: 
python3 knight_game.py

It will read moves from the file moves.txt in the same directory.

To run the unit tests:
python3 test_game.py

The unit tests will use both moves.txt and moves2.txt as test input data.
